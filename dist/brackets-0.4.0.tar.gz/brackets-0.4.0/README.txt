Brackets
========

.. figure:: https://github.com/pooya-eghbali/brackets/raw/master/logo.png
   :alt: Python Brackets

   alt text

Brackets is a yet-another, a not just a pre-processor, a language built
on top of Python, allowing to use {} instead of indentation in Python,
and it allows defining powerful anonymous functions and introduces much
more sugar and candy into Python's syntax and abilities.

Visit `Brackets Website <http://python-brackets.org>`__ for docs and
more info.
